# Deploying the UroApp Website — 5-Minute Guide

This folder is a complete, deploy-ready project:

```
uroapp-website/
├── index.html        ← the full site (works standalone too)
├── api/evidence.js   ← serverless AI proxy (keeps your API key secret)
├── package.json
└── DEPLOY.md         ← this file
```

## Step 1 — Get an Anthropic API key
Create one at **https://console.anthropic.com** (Settings → API Keys).
Pricing is per-token; check current rates at https://docs.claude.com before launch.

## Step 2 — Deploy to Vercel (recommended, free hobby tier)

**Easiest path (no terminal):**
1. Create a free account at https://vercel.com
2. Push this folder to a GitHub repository (or use Vercel's "Deploy from local" via CLI below)
3. In Vercel: **Add New → Project → Import** your repo
4. Under **Environment Variables**, add: `ANTHROPIC_API_KEY` = your key
5. Click **Deploy** → you get a live URL like `uroapp.vercel.app`

**Terminal path (from inside this folder on your Mac/PC):**
```bash
npx vercel login
npx vercel                 # first deploy (accept defaults)
npx vercel env add ANTHROPIC_API_KEY production   # paste your key
npx vercel --prod          # production deploy
```

## Step 3 — Test
Open your live URL → scroll to **Evidence AI** → ask a question.
The page calls `/api/evidence` on your own domain; the key never reaches the browser.

## Step 4 — Custom domain (optional)
In Vercel: Project → Settings → Domains → add e.g. `uroapp.app` or a `.sa` domain
(purchase the domain separately from any registrar; for `.sa` domains see https://nic.sa).

## Cost & abuse protection (important before sharing publicly)
- Every AI question costs API tokens billed to your key. Before promoting the site:
  - Set a **spend limit** in the Anthropic Console
  - Add rate limiting (Vercel → Project → Firewall, or gate the AI behind a simple email sign-up)
- The function already caps history at 40 messages × 4,000 chars to limit abuse.

## Notes
- Static-only hosts (GitHub Pages, plain S3) will serve the site fine but the
  AI section won't work there — it needs the serverless function. Use Vercel,
  Netlify (function needs minor adaptation), or Cloudflare Pages.
- Verify the current model string at https://docs.claude.com and update
  `api/evidence.js` if needed.
- The calculators/pricing shown are marketing content; keep the medical
  disclaimer visible on any page that gives clinical information.
