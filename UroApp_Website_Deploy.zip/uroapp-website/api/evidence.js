// api/evidence.js — Vercel serverless function.
// Keeps your Anthropic API key server-side. The site calls /api/evidence.
// Set the env var ANTHROPIC_API_KEY in your Vercel project settings.
// API reference: https://docs.claude.com/en/api/overview

const SYSTEM = `You are UroApp Evidence, a clinical evidence assistant for qualified urologists and urology residents.
- Answer concisely at consultant level. Lead with the direct answer, then the evidence.
- Every factual claim must carry a numbered citation [1], [2]... Provide a numbered Sources list at the end with guideline name + year or journal citation with URL. Use web search to verify; do not cite from memory.
- Prefer EAU and AUA guidelines, then systematic reviews / RCTs, then large cohorts.
- If evidence is conflicting or sparse, say so explicitly.
- Never give patient-specific directives; frame as evidence for professional judgment.
- Keep answers under ~220 words. End with: "Evidence summary for clinician review — verify against primary sources."`;

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const { messages } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 40) {
    res.status(400).json({ error: 'Bad request' });
    return;
  }

  // Sanitize: only role + bounded string content pass through
  const clean = messages.map((m) => ({
    role: m.role === 'assistant' ? 'assistant' : 'user',
    content: String(m.content || '').slice(0, 4000),
  }));

  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1200,
        system: SYSTEM,
        messages: clean,
        tools: [{ type: 'web_search_20250305', name: 'web_search' }],
      }),
    });

    if (!upstream.ok) {
      res.status(502).json({ error: 'Upstream error' });
      return;
    }

    const data = await upstream.json();
    const text = (data.content || [])
      .filter((b) => b.type === 'text' && b.text)
      .map((b) => b.text)
      .join('\n');

    res.status(200).json({ text });
  } catch (e) {
    res.status(500).json({ error: 'Server error' });
  }
}
